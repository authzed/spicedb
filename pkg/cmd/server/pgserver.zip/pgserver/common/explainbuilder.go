package common

import "fmt"

type ExplainBuilder struct {
	unsupported  bool
	withoutStats bool
	tableName    string
}

func NewExplainBuilder(tableName string) *ExplainBuilder {
	return &ExplainBuilder{tableName: tableName}
}

func (eb *ExplainBuilder) WithUnsupported() *ExplainBuilder {
	eb.unsupported = true
	return eb
}

func (eb *ExplainBuilder) WithoutStats() *ExplainBuilder {
	eb.withoutStats = true
	return eb
}

func (eb *ExplainBuilder) ExplainString() string {
	if eb.unsupported {
		return fmt.Sprintf(`Seq Scan on %s (cost=0.00..100000000000000000000000000000000000000000000 rows=3000 width=96)`, eb.tableName)
	}
	if eb.withoutStats {
		return fmt.Sprintf(`Seq Scan on %s (cost=0.00..100 rows=10000 width=96)`, eb.tableName)
	}

	return "EXPLAIN PLAN"
}
