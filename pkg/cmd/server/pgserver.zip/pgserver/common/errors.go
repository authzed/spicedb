package common

import (
	"fmt"

	"github.com/jeroenrinzema/psql-wire/codes"
	psqlerr "github.com/jeroenrinzema/psql-wire/errors"
)

func NewUnsupportedError(baseErr error) error {
	err := fmt.Errorf("unsupported feature or query type: %w", baseErr)
	err = psqlerr.WithCode(err, codes.FeatureNotSupported)
	err = psqlerr.WithSeverity(err, psqlerr.LevelFatal)
	return err
}

func NewSemanticsError(baseErr error) error {
	err := fmt.Errorf("semantic error: %w", baseErr)
	err = psqlerr.WithCode(err, codes.InvalidParameterValue)
	err = psqlerr.WithSeverity(err, psqlerr.LevelFatal)
	return err
}

func NewQueryError(baseErr error) error {
	err := fmt.Errorf("query error: %w", baseErr)
	err = psqlerr.WithCode(err, codes.InvalidParameterValue)
	err = psqlerr.WithSeverity(err, psqlerr.LevelError)
	return err
}
