package pgserver

import (
	"context"
	"fmt"

	"github.com/authzed/spicedb/internal/dispatch"
	log "github.com/authzed/spicedb/internal/logging"
	"github.com/authzed/spicedb/pkg/datastore"
	wire "github.com/jeroenrinzema/psql-wire"
	pg_query "github.com/pganalyze/pg_query_go/v6"
)

type PgBackend struct {
	ds         datastore.Datastore
	dispatcher dispatch.Dispatcher
	server     *wire.Server
}

func NewPgBackend(ds datastore.Datastore, dispatcher dispatch.Dispatcher) *PgBackend {
	connHandler := &PgBackend{ds: ds, dispatcher: dispatcher}
	return connHandler
}

func (p *PgBackend) Run(ctx context.Context, endpoint string) error {
	server, err := wire.NewServer(p.handler, wire.SessionMiddleware(sessionMiddleware))
	if err != nil {
		return err
	}

	//slog.SetLogLoggerLevel(slog.LevelDebug)

	p.server = server
	return p.server.ListenAndServe(endpoint)
}

func (p *PgBackend) Close() error {
	return p.server.Close()
}

func (p *PgBackend) handler(ctx context.Context, query string) (wire.PreparedStatements, error) {
	parsed, err := pg_query.Parse(query)
	if err != nil {
		return nil, fmt.Errorf("failed to parse query: %w", err)
	}

	if len(parsed.Stmts) != 1 {
		return nil, fmt.Errorf("multiple statements not supported")
	}

	log.Trace().Str("query", query).Msg("pg backend query")

	stmt := parsed.Stmts[0].Stmt
	switch {
	// SET variable = value
	case stmt.GetVariableSetStmt() != nil:
		handle := func(ctx context.Context, writer wire.DataWriter, parameters []wire.Parameter) error {
			return writer.Complete("set ignored")
		}
		return wire.Prepared(wire.NewStatement(handle)), nil

	// EXPLAIN SELECT ...
	case stmt.GetExplainStmt() != nil:
		return p.handleExplainStmt(ctx, stmt.GetExplainStmt(), query)

	// DEALLOCATE c1
	// DEALLOCATE ALL
	case stmt.GetDeallocateStmt() != nil:
		return p.handleDeallocateStmt(ctx, stmt.GetDeallocateStmt(), query)

	// INSERT INTO ...
	case stmt.GetInsertStmt() != nil:
		return p.handleInsertStmt(ctx, stmt.GetInsertStmt(), query)

	// DECLARE c1 CURSOR FOR SELECT ...
	case stmt.GetDeclareCursorStmt() != nil:
		return p.handleDeclareCursorStmt(ctx, stmt.GetDeclareCursorStmt(), query)

	// FETCH 100 FROM c1
	case stmt.GetFetchStmt() != nil:
		return p.handleFetchStmt(ctx, stmt.GetFetchStmt(), query)

	// CLOSE c1
	case stmt.GetClosePortalStmt() != nil:
		return p.handleClosePortalStmt(ctx, stmt.GetClosePortalStmt(), query)

	// START TRANSACTION
	// COMMIT
	// ABORT TRANSACTION
	case stmt.GetTransactionStmt() != nil:
		return p.handleTransactionStmt(ctx, stmt.GetTransactionStmt(), query)

	default:
		return nil, fmt.Errorf("not implemented: %v", stmt)
	}
}
