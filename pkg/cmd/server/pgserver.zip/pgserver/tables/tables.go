package tables

import (
	"context"

	"github.com/authzed/spicedb/internal/dispatch"
	"github.com/authzed/spicedb/pkg/datastore"
	wire "github.com/jeroenrinzema/psql-wire"
	pg_query "github.com/pganalyze/pg_query_go/v6"
)

type insertRunner func(ctx context.Context, ds datastore.Datastore, insertStmt *InsertStatement, parameters []wire.Parameter) (int64, error)
type insertValidator func(ctx context.Context, stmt *pg_query.InsertStmt) (map[string]any, error)

type selectHandler func(ctx context.Context, ds datastore.Datastore, dispatcher dispatch.Dispatcher, parameters []wire.Parameter, howMany int64, writer wire.DataWriter, rowsCursor RowsCursor, selectStmt *SelectStatement) (RowsCursor, error)
type selectHandlerBuilder func(fields map[string]valueOrRef) (selectHandler, error)

type explainHandler func(ctx context.Context, ds datastore.Datastore, writer wire.DataWriter) error
type explainHandlerBuilder func(fields map[string]valueOrRef) (explainHandler, error)

type tableDefinition struct {
	name                  string
	schema                wire.Columns
	insertValidator       insertValidator
	insertRunner          insertRunner
	buildSelectHandler    selectHandlerBuilder
	buildExplainHandler   explainHandlerBuilder
	requiredInsertColumns []string
}

func (td tableDefinition) hasColumn(colName string) bool {
	for _, col := range td.schema {
		if col.Name == colName {
			return true
		}
	}
	return false
}

func (td tableDefinition) columnNames() []string {
	names := make([]string, len(td.schema))
	for i, col := range td.schema {
		names[i] = col.Name
	}
	return names
}

func (td tableDefinition) getSchemaColumn(name string) (wire.Column, bool) {
	for _, col := range td.schema {
		if col.Name == name {
			return col, true
		}
	}
	return wire.Column{}, false
}

var tables = map[string]tableDefinition{
	"relationships": {
		name:                  "relationships",
		schema:                relationshipsSchema,
		insertRunner:          relationshipsInsertRunner,
		insertValidator:       relationshipInsertValidator,
		buildSelectHandler:    buildRelationshipsSelectHandler,
		buildExplainHandler:   buildRelationshipsExplainHandler,
		requiredInsertColumns: relationshipsRequiredInsertColumns,
	},
	"permissions": {
		name:                "permissions",
		schema:              permissionsSchema,
		buildSelectHandler:  buildPermissionsSelectHandler,
		buildExplainHandler: buildPermissionsExplainHandler,
	},
}
