package tables

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/authzed/spicedb/internal/dispatch"
	"github.com/authzed/spicedb/internal/relationships"
	"github.com/authzed/spicedb/pkg/cmd/server/pgserver/common"
	"github.com/authzed/spicedb/pkg/datastore"
	"github.com/authzed/spicedb/pkg/datastore/options"
	corev1 "github.com/authzed/spicedb/pkg/proto/core/v1"
	"github.com/authzed/spicedb/pkg/tuple"
	wire "github.com/jeroenrinzema/psql-wire"
	"github.com/jzelinskie/stringz"
	"github.com/lib/pq/oid"
	pg_query "github.com/pganalyze/pg_query_go/v6"
	"google.golang.org/protobuf/types/known/structpb"
)

var relationshipsRequiredInsertColumns = []string{
	"resource_type",
	"resource_id",
	"relation",
	"subject_type",
	"subject_id",
	"optional_subject_relation",
}

var relationshipsSchema = wire.Columns{
	{
		Table: 0,
		Name:  "resource_type",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "resource_id",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "relation",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "subject_type",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "subject_id",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "optional_subject_relation",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "caveat_name",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "caveat_context",
		Oid:   oid.T_text,
		Width: 256,
	},
}

func buildRelationshipsSelectHandler(fields map[string]valueOrRef) (selectHandler, error) {
	if _, ok := fields["caveat_context"]; ok {
		return nil, fmt.Errorf("caveat_context is not supported in SELECT queries")
	}

	for fieldName, fieldValue := range fields {
		if fieldValue.value == "" {
			return nil, fmt.Errorf("field %q cannot be empty", fieldName)
		}
	}

	filter := datastore.RelationshipsFilter{}
	if resourceType, ok := fields["resource_type"]; ok {
		filter.OptionalResourceType = resourceType.value
	}
	if resourceID, ok := fields["resource_id"]; ok {
		filter.OptionalResourceIds = []string{resourceID.value}
	}
	if relation, ok := fields["relation"]; ok {
		filter.OptionalResourceRelation = relation.value
	}

	if subjectType, ok := fields["subject_type"]; ok {
		if len(filter.OptionalSubjectsSelectors) == 0 {
			filter.OptionalSubjectsSelectors = make([]datastore.SubjectsSelector, 1)
		}
		filter.OptionalSubjectsSelectors[0].OptionalSubjectType = subjectType.value
	}

	if subjectID, ok := fields["subject_id"]; ok {
		if len(filter.OptionalSubjectsSelectors) == 0 {
			filter.OptionalSubjectsSelectors = make([]datastore.SubjectsSelector, 1)
		}
		filter.OptionalSubjectsSelectors[0].OptionalSubjectIds = []string{subjectID.value}
	}

	if subjectRelation, ok := fields["optional_subject_relation"]; ok {
		if len(filter.OptionalSubjectsSelectors) == 0 {
			filter.OptionalSubjectsSelectors = make([]datastore.SubjectsSelector, 1)
		}

		filter.OptionalSubjectsSelectors[0].RelationFilter = datastore.SubjectRelationFilter{
			NonEllipsisRelation: subjectRelation.value,
		}
	}

	return readRelationshipsWithFilter(filter), nil
}

func readRelationshipsWithFilter(filter datastore.RelationshipsFilter) selectHandler {
	return func(ctx context.Context, ds datastore.Datastore, dispatcher dispatch.Dispatcher, parameters []wire.Parameter, howMany int64, writer wire.DataWriter, rowsCursor RowsCursor, selectStatement *SelectStatement) (RowsCursor, error) {
		headRev, err := ds.HeadRevision(ctx)
		if err != nil {
			return nil, err
		}

		reader := ds.SnapshotReader(headRev)
		limit := uint64(howMany)

		var currentCursor options.Cursor
		if rowsCursor != nil {
			currentCursor = rowsCursor.(options.Cursor)
		}

		iter, err := reader.QueryRelationships(ctx, filter,
			options.WithSort(options.ByResource),
			options.WithAfter(currentCursor),
			options.WithLimit(&limit),
		)

		if err != nil {
			return nil, fmt.Errorf("error querying relationships: %w", err)
		}

		rowCount := 0
		for rel, err := range iter {
			if err != nil {
				return nil, fmt.Errorf("error iterating relationships: %w", err)
			}

			caveatName := ""
			var caveatContext *string
			if rel.OptionalCaveat != nil {
				caveatName = rel.OptionalCaveat.CaveatName
				cctx, err := json.Marshal(rel.OptionalCaveat.Context.AsMap())
				if err != nil {
					return nil, fmt.Errorf("error marshaling caveat context: %w", err)
				}

				cctxStr := string(cctx)
				caveatContext = &cctxStr
			}

			subjectRel := stringz.Default(rel.Subject.Relation, "", tuple.Ellipsis)

			rowValues := make([]any, 0, len(selectStatement.columnNames))
			for _, colName := range selectStatement.columnNames {
				switch colName {
				case "resource_type":
					rowValues = append(rowValues, rel.Resource.ObjectType)
				case "resource_id":
					rowValues = append(rowValues, rel.Resource.ObjectID)
				case "relation":
					rowValues = append(rowValues, rel.Resource.Relation)
				case "subject_type":
					rowValues = append(rowValues, rel.Subject.ObjectType)
				case "subject_id":
					rowValues = append(rowValues, rel.Subject.ObjectID)
				case "optional_subject_relation":
					rowValues = append(rowValues, subjectRel)
				case "caveat_name":
					rowValues = append(rowValues, caveatName)
				case "caveat_context":
					rowValues = append(rowValues, caveatContext)
				default:
					return nil, fmt.Errorf("unsupported column %q", colName)
				}
			}

			writer.Row(rowValues)
			currentCursor = &rel
			rowCount++
		}
		return currentCursor, writer.Complete(fmt.Sprintf("SELECT %d", rowCount))
	}
}

func buildRelationshipsExplainHandler(fields map[string]valueOrRef) (explainHandler, error) {
	return func(ctx context.Context, ds datastore.Datastore, writer wire.DataWriter) error {
		writer.Row([]any{common.NewExplainBuilder("relationships").WithoutStats().ExplainString()})
		return writer.Complete("EXPLAIN")
	}, nil
}

func relationshipsInsertRunner(ctx context.Context, ds datastore.Datastore, insertStmt *InsertStatement, parameters []wire.Parameter) (int64, error) {
	valuesByColumnName := make(map[string]string, len(insertStmt.colNames))
	for i, colName := range insertStmt.colNames {
		// TODO: support other column types here if necessary.
		valuesByColumnName[colName] = string(parameters[i].Value())
	}

	rel := tuple.Relationship{
		RelationshipReference: tuple.RelationshipReference{
			Resource: tuple.ObjectAndRelation{
				ObjectType: valuesByColumnName["resource_type"],
				ObjectID:   valuesByColumnName["resource_id"],
				Relation:   valuesByColumnName["relation"],
			},
			Subject: tuple.ObjectAndRelation{
				ObjectType: valuesByColumnName["subject_type"],
				ObjectID:   valuesByColumnName["subject_id"],
				Relation:   stringz.Default(valuesByColumnName["optional_subject_relation"], tuple.Ellipsis, ""),
			},
		},
	}

	if caveatName, ok := valuesByColumnName["caveat_name"]; ok && len(caveatName) > 0 {
		rel.OptionalCaveat = &corev1.ContextualizedCaveat{
			CaveatName: caveatName,
		}
		if caveatContextString, ok := valuesByColumnName["caveat_context"]; ok && len(caveatContextString) > 0 {
			// Parse the caveat context into a structpb.
			var contextMap map[string]any
			err := json.Unmarshal([]byte(caveatContextString), &contextMap)
			if err != nil {
				return 0, common.NewQueryError(fmt.Errorf("invalid caveat context JSON: %w", err))
			}

			caveatContext, err := structpb.NewStruct(contextMap)
			if err != nil {
				return 0, common.NewQueryError(fmt.Errorf("invalid caveat context: %w", err))
			}

			rel.OptionalCaveat.Context = caveatContext
		}
	}

	// Write the relationship.
	_, err := ds.ReadWriteTx(ctx, func(ctx context.Context, tx datastore.ReadWriteTransaction) error {
		relUpdates := []tuple.RelationshipUpdate{
			{
				Operation:    insertStmt.metadata["writeOp"].(tuple.UpdateOperation),
				Relationship: rel,
			},
		}

		// Type check.
		if err := relationships.ValidateRelationshipUpdates(ctx, tx, relUpdates); err != nil {
			return err
		}

		return tx.WriteRelationships(ctx, relUpdates)
	})
	if err != nil {
		return 0, common.NewQueryError(fmt.Errorf("failed to write relationship: %w", err))
	}

	return 1, nil
}

func relationshipInsertValidator(ctx context.Context, query *pg_query.InsertStmt) (map[string]any, error) {
	// Parse the write operation.
	writeOp := tuple.UpdateOperationCreate
	if query.GetOnConflictClause() != nil {
		if query.GetOnConflictClause().Action != pg_query.OnConflictAction_ONCONFLICT_NOTHING {
			return nil, common.NewQueryError(fmt.Errorf("only ON CONFLICT DO NOTHING is supported"))
		}

		writeOp = tuple.UpdateOperationTouch
	}

	return map[string]any{
		"writeOp": writeOp,
	}, nil
}
