package tables

import (
	"context"
	"errors"
	"fmt"

	"github.com/authzed/spicedb/internal/dispatch"
	datastoremw "github.com/authzed/spicedb/internal/middleware/datastore"
	"github.com/authzed/spicedb/pkg/cmd/server/pgserver/common"
	"github.com/authzed/spicedb/pkg/datastore"
	corev1 "github.com/authzed/spicedb/pkg/proto/core/v1"
	dispatchv1 "github.com/authzed/spicedb/pkg/proto/dispatch/v1"
	"github.com/authzed/spicedb/pkg/tuple"
	wire "github.com/jeroenrinzema/psql-wire"
	"github.com/jzelinskie/stringz"
	"github.com/lib/pq/oid"
)

var permissionsSchema = wire.Columns{
	{
		Table: 0,
		Name:  "resource_type",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "resource_id",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "permission",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "subject_type",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "subject_id",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "optional_subject_relation",
		Oid:   oid.T_text,
		Width: 256,
	},
	{
		Table: 0,
		Name:  "has_permission",
		Oid:   oid.T_bool,
		Width: 256,
	},
}

func buildPermissionsSelectHandler(fields map[string]valueOrRef) (selectHandler, error) {
	if _, ok := fields["has_permission"]; ok {
		return nil, common.NewQueryError(errors.New("cannot select has_permission value"))
	}

	hasFields := func(fieldNames ...string) bool {
		for _, fieldName := range fieldNames {
			if _, ok := fields[fieldName]; !ok {
				return false
			}
		}
		return true
	}

	// If all fields are defined, this is a CheckPermission request.
	if hasFields("resource_type", "resource_id", "permission", "subject_type", "subject_id") {
		return buildCheckPermissionHandler(fields)
	}

	// If all fields except resource_id are defined, this is a LookupResources request.
	if hasFields("resource_type", "permission", "subject_type", "subject_id") {
		return buildLookupResourcesHandler(fields)
	}

	// If all fields except subject_id are defined, this is a LookupSubjects request.
	if hasFields("resource_type", "resource_id", "permission", "subject_type") {
		return buildLookupSubjectsHandler(fields)
	}

	// Otherwise, this is unsupported.
	return nil, common.NewQueryError(errors.New("unsupported query for permissions table"))
}

func stringValue(valueOrRef valueOrRef, parameters []wire.Parameter) (string, error) {
	if valueOrRef.isSubQueryPlaceholder {
		return "", fmt.Errorf("subquery placeholders are not supported in permissions table")
	}

	if valueOrRef.parameterIndex > 0 {
		if int(valueOrRef.parameterIndex) >= len(parameters) {
			return "", fmt.Errorf("parameter index out of range")
		}
		return string(parameters[int(valueOrRef.parameterIndex)].Value()), nil
	}

	if valueOrRef.value == "" {
		return "", fmt.Errorf("value is empty")
	}

	return valueOrRef.value, nil
}

func optionalStringValue(valueOrRef valueOrRef, parameters []wire.Parameter) (string, error) {
	if valueOrRef.isSubQueryPlaceholder {
		return "", fmt.Errorf("subquery placeholders are not supported in permissions table")
	}

	if valueOrRef.parameterIndex > 0 {
		if int(valueOrRef.parameterIndex) >= len(parameters) {
			return "", fmt.Errorf("parameter index out of range")
		}
		return string(parameters[int(valueOrRef.parameterIndex)].Value()), nil
	}

	return valueOrRef.value, nil
}

func buildCheckPermissionHandler(fields map[string]valueOrRef) (selectHandler, error) {
	return func(ctx context.Context, ds datastore.Datastore, dispatcher dispatch.Dispatcher, parameters []wire.Parameter, howMany int64, writer wire.DataWriter, rowsCursor RowsCursor, selectStatement *SelectStatement) (RowsCursor, error) {
		ctx = datastoremw.ContextWithDatastore(ctx, ds)

		resource_type, err := stringValue(fields["resource_type"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting resource_type: %w", err)
		}

		resource_id, err := stringValue(fields["resource_id"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting resource_id: %w", err)
		}

		permission, err := stringValue(fields["permission"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting permission: %w", err)
		}

		subject_type, err := stringValue(fields["subject_type"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting subject_type: %w", err)
		}

		subject_id, err := stringValue(fields["subject_id"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting subject_id: %w", err)
		}

		optional_subject_relation, err := optionalStringValue(fields["optional_subject_relation"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting optional_subject_relation: %w", err)
		}

		headRev, err := ds.HeadRevision(ctx)
		if err != nil {
			return nil, fmt.Errorf("error getting head revision: %w", err)
		}

		checkResult, err := dispatcher.DispatchCheck(ctx, &dispatchv1.DispatchCheckRequest{
			ResourceRelation: &corev1.RelationReference{
				Namespace: resource_type,
				Relation:  permission,
			},
			ResourceIds: []string{resource_id},
			Subject: &corev1.ObjectAndRelation{
				Namespace: subject_type,
				ObjectId:  subject_id,
				Relation:  stringz.Default(optional_subject_relation, tuple.Ellipsis, ""),
			},
			Metadata: &dispatchv1.ResolverMeta{
				AtRevision:     headRev.String(),
				DepthRemaining: 50,
			},
		})
		if err != nil {
			return nil, fmt.Errorf("error dispatching check: %w", err)
		}

		hasPermission := false
		if result, ok := checkResult.ResultsByResourceId[resource_id]; ok {
			hasPermission = result.Membership == dispatchv1.ResourceCheckResult_MEMBER
		}

		writer.Row([]any{
			resource_type,
			resource_id,
			permission,
			subject_type,
			subject_id,
			optional_subject_relation,
			hasPermission,
		})
		return nil, writer.Complete("SELECT")
	}, nil
}

func buildLookupResourcesHandler(fields map[string]valueOrRef) (selectHandler, error) {
	return func(ctx context.Context, ds datastore.Datastore, dispatcher dispatch.Dispatcher, parameters []wire.Parameter, howMany int64, writer wire.DataWriter, rowsCursor RowsCursor, selectStatement *SelectStatement) (RowsCursor, error) {
		ctx = datastoremw.ContextWithDatastore(ctx, ds)

		resource_type, err := stringValue(fields["resource_type"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting resource_type: %w", err)
		}

		permission, err := stringValue(fields["permission"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting permission: %w", err)
		}

		subject_type, err := stringValue(fields["subject_type"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting subject_type: %w", err)
		}

		subject_id, err := stringValue(fields["subject_id"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting subject_id: %w", err)
		}

		optional_subject_relation, err := optionalStringValue(fields["optional_subject_relation"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting optional_subject_relation: %w", err)
		}

		headRev, err := ds.HeadRevision(ctx)
		if err != nil {
			return nil, fmt.Errorf("error getting head revision: %w", err)
		}

		// TODO: don't collect but instead stream in real time
		// TODO: support cursors
		stream := dispatch.NewCollectingDispatchStream[*dispatchv1.DispatchLookupResources2Response](ctx)
		err = dispatcher.DispatchLookupResources2(&dispatchv1.DispatchLookupResources2Request{
			ResourceRelation: &corev1.RelationReference{
				Namespace: resource_type,
				Relation:  permission,
			},
			SubjectRelation: &corev1.RelationReference{
				Namespace: subject_type,
				Relation:  stringz.Default(optional_subject_relation, tuple.Ellipsis, ""),
			},
			SubjectIds: []string{subject_id},
			TerminalSubject: &corev1.ObjectAndRelation{
				Namespace: subject_type,
				ObjectId:  subject_id,
				Relation:  stringz.Default(optional_subject_relation, tuple.Ellipsis, ""),
			},
			Metadata: &dispatchv1.ResolverMeta{
				AtRevision:     headRev.String(),
				DepthRemaining: 50,
			},
			OptionalLimit: uint32(howMany),
		}, stream)
		if err != nil {
			return nil, fmt.Errorf("error dispatching lr: %w", err)
		}

		for _, result := range stream.Results() {
			writer.Row([]any{
				resource_type,
				result.Resource.ResourceId,
				permission,
				subject_type,
				subject_id,
				optional_subject_relation,
				true,
			})
		}

		return nil, writer.Complete("SELECT")
	}, nil
}

func buildLookupSubjectsHandler(fields map[string]valueOrRef) (selectHandler, error) {
	return func(ctx context.Context, ds datastore.Datastore, dispatcher dispatch.Dispatcher, parameters []wire.Parameter, howMany int64, writer wire.DataWriter, rowsCursor RowsCursor, selectStatement *SelectStatement) (RowsCursor, error) {
		ctx = datastoremw.ContextWithDatastore(ctx, ds)

		resource_type, err := stringValue(fields["resource_type"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting resource_type: %w", err)
		}

		resource_id, err := stringValue(fields["resource_id"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting resource_id: %w", err)
		}

		permission, err := stringValue(fields["permission"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting permission: %w", err)
		}

		subject_type, err := stringValue(fields["subject_type"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting subject_type: %w", err)
		}

		optional_subject_relation, err := optionalStringValue(fields["optional_subject_relation"], parameters)
		if err != nil {
			return nil, fmt.Errorf("error getting optional_subject_relation: %w", err)
		}

		headRev, err := ds.HeadRevision(ctx)
		if err != nil {
			return nil, fmt.Errorf("error getting head revision: %w", err)
		}

		// TODO: don't collect but instead stream in real time
		// TODO: support cursors and limit
		stream := dispatch.NewCollectingDispatchStream[*dispatchv1.DispatchLookupSubjectsResponse](ctx)
		err = dispatcher.DispatchLookupSubjects(&dispatchv1.DispatchLookupSubjectsRequest{
			ResourceRelation: &corev1.RelationReference{
				Namespace: resource_type,
				Relation:  permission,
			},
			SubjectRelation: &corev1.RelationReference{
				Namespace: subject_type,
				Relation:  stringz.Default(optional_subject_relation, tuple.Ellipsis, ""),
			},
			ResourceIds: []string{resource_id},
			Metadata: &dispatchv1.ResolverMeta{
				AtRevision:     headRev.String(),
				DepthRemaining: 50,
			},
		}, stream)
		if err != nil {
			return nil, fmt.Errorf("error dispatching lr: %w", err)
		}

		for _, result := range stream.Results() {
			for _, foundSubjects := range result.FoundSubjectsByResourceId {
				for _, fs := range foundSubjects.FoundSubjects {
					writer.Row([]any{
						resource_type,
						resource_id,
						permission,
						subject_type,
						fs.SubjectId,
						optional_subject_relation,
						true,
					})
				}
			}
		}

		return nil, writer.Complete("SELECT")
	}, nil
}

func buildPermissionsExplainHandler(fields map[string]valueOrRef) (explainHandler, error) {
	return func(ctx context.Context, ds datastore.Datastore, writer wire.DataWriter) error {
		writer.Row([]any{common.NewExplainBuilder("permissions").WithoutStats().ExplainString()})
		return writer.Complete("EXPLAIN")
	}, nil
}
