package tables

import (
	"context"
	"fmt"

	"github.com/authzed/spicedb/internal/dispatch"
	"github.com/authzed/spicedb/pkg/cmd/server/pgserver/common"
	"github.com/authzed/spicedb/pkg/datastore"
	wire "github.com/jeroenrinzema/psql-wire"
	pg_query "github.com/pganalyze/pg_query_go/v6"
)

// RowsCursor is a placeholder for the actual cursor type used by the select statement.
type RowsCursor any

type SelectStatement struct {
	isUnsupported bool

	tableName      string
	tableDef       tableDefinition
	columnNames    []string
	fields         map[string]valueOrRef
	selectHandler  selectHandler
	explainHandler explainHandler
}

func ParseSelectStatement(query *pg_query.SelectStmt, forExplain bool) (*SelectStatement, error) {
	if query == nil {
		return nil, common.NewUnsupportedError(fmt.Errorf("only SELECT is supported"))
	}

	// FROM
	fromClauses := query.GetFromClause()
	if len(fromClauses) != 1 {
		return nil, common.NewUnsupportedError(fmt.Errorf("a select statement must have exactly one FROM clause"))
	}

	fromVar := fromClauses[0].GetRangeVar()
	if fromVar == nil {
		return nil, common.NewUnsupportedError(fmt.Errorf("a select statement must have a FROM clause pointing to a single table"))
	}

	tableName := fromVar.GetRelname()
	tableDef, ok := tables[tableName]
	if !ok {
		return nil, common.NewUnsupportedError(fmt.Errorf("table %s does not exist", tableName))
	}

	// Check for * or column names.
	columnNames := make([]string, 0)
	if len(query.GetTargetList()) == 1 && query.GetTargetList()[0].GetResTarget().GetName() == "*" {
		columnNames = tableDef.columnNames()
	} else {
		for _, target := range query.GetTargetList() {
			if target.GetResTarget() == nil {
				return nil, common.NewUnsupportedError(fmt.Errorf("a select statement must have a target list"))
			}

			if target.GetResTarget().GetVal() == nil {
				return nil, common.NewUnsupportedError(fmt.Errorf("a select statement must have a target list with a value"))
			}

			if target.GetResTarget().GetVal().GetColumnRef() == nil {
				return nil, common.NewUnsupportedError(fmt.Errorf("a select statement must have a target list with a column reference"))
			}

			if target.GetResTarget().GetVal().GetColumnRef().GetFields() == nil {
				return nil, common.NewUnsupportedError(fmt.Errorf("a select statement must have a target list with a column reference"))
			}

			if len(target.GetResTarget().GetVal().GetColumnRef().GetFields()) != 1 {
				return nil, common.NewUnsupportedError(fmt.Errorf("a select statement must have a target list with a single column reference"))
			}

			if target.GetResTarget().GetVal().GetColumnRef().GetFields()[0].GetString_() == nil {
				return nil, common.NewUnsupportedError(fmt.Errorf("a select statement must have a target list with a column reference"))
			}

			if target.GetResTarget().GetVal().GetColumnRef().GetFields()[0].GetString_().Sval == "" {
				return nil, common.NewUnsupportedError(fmt.Errorf("a select statement must have a target list with a column reference"))
			}

			columnName := target.GetResTarget().GetVal().GetColumnRef().GetFields()[0].GetString_().Sval
			if !tableDef.hasColumn(columnName) {
				return nil, common.NewUnsupportedError(fmt.Errorf("column %s does not exist in table %s", columnName, tableName))
			}

			columnNames = append(columnNames, columnName)
		}
	}

	// Ensure unused clauses are not present.
	if err := checkUnusedSelectClauses(query); err != nil {
		return &SelectStatement{
			isUnsupported: true,
			tableName:     tableName,
			tableDef:      tableDef,
		}, common.NewUnsupportedError(fmt.Errorf("unsupported select statement: %w", err))
	}

	fields := make(map[string]valueOrRef)
	if err := collectSelectWhereClauses(query.GetWhereClause(), fields); err != nil {
		return &SelectStatement{
			isUnsupported: true,
			tableName:     tableName,
			tableDef:      tableDef,
		}, common.NewUnsupportedError(fmt.Errorf("unsupported select statement: %w", err))
	}

	// Ensure all fields matchn the table definition.
	for fieldName := range fields {
		if !tableDef.hasColumn(fieldName) {
			return &SelectStatement{
				isUnsupported: true,
				tableName:     tableName,
				tableDef:      tableDef,
			}, common.NewUnsupportedError(fmt.Errorf("field %s does not exist in table %s", fieldName, tableName))
		}
	}

	if forExplain {
		explainHandler, err := tableDef.buildExplainHandler(fields)
		if err != nil {
			return &SelectStatement{
				isUnsupported: true,
				tableName:     tableName,
				tableDef:      tableDef,
			}, common.NewUnsupportedError(fmt.Errorf("unsupported select statement: %w", err))
		}

		return &SelectStatement{
			tableName:      tableName,
			tableDef:       tableDef,
			fields:         fields,
			explainHandler: explainHandler,
		}, nil
	} else {
		selectHandler, err := tableDef.buildSelectHandler(fields)
		if err != nil {
			return &SelectStatement{
				isUnsupported: true,
				tableName:     tableName,
				tableDef:      tableDef,
			}, common.NewUnsupportedError(fmt.Errorf("unsupported select statement: %w", err))
		}

		return &SelectStatement{
			tableName:     tableName,
			tableDef:      tableDef,
			fields:        fields,
			selectHandler: selectHandler,
			columnNames:   columnNames,
		}, nil
	}
}

func (ss *SelectStatement) IsUnsupported() bool {
	return ss.isUnsupported
}

func (ss *SelectStatement) Schema() wire.Columns {
	columns := make(wire.Columns, 0, len(ss.columnNames))
	for _, columnName := range ss.columnNames {
		schemaColumn, _ := ss.tableDef.getSchemaColumn(columnName)
		columns = append(columns, schemaColumn)
	}

	return columns
}

func (ss *SelectStatement) TableName() string {
	return ss.tableName
}

func (ss *SelectStatement) Fetch(ctx context.Context, ds datastore.Datastore, dispatcher dispatch.Dispatcher, parameters []wire.Parameter, writer wire.DataWriter, howMany int64, rowsCursor RowsCursor, selectStmt *SelectStatement) (RowsCursor, error) {
	if ss.isUnsupported {
		return nil, common.NewUnsupportedError(fmt.Errorf("this query is unsupported"))
	}

	return ss.selectHandler(ctx, ds, dispatcher, parameters, howMany, writer, rowsCursor, selectStmt)
}

func (ss *SelectStatement) Explain(ctx context.Context, ds datastore.Datastore, writer wire.DataWriter) error {
	if ss.isUnsupported {
		return common.NewUnsupportedError(fmt.Errorf("this query is unsupported"))
	}

	return ss.explainHandler(ctx, ds, writer)
}

func checkUnusedSelectClauses(selectStatement *pg_query.SelectStmt) error {
	if selectStatement.GetDistinctClause() != nil {
		return fmt.Errorf("DISTINCT not supported")
	}

	if selectStatement.GetGroupClause() != nil {
		return fmt.Errorf("GROUP BY not supported")
	}

	if selectStatement.GetGroupDistinct() {
		return fmt.Errorf("GROUP BY not supported")
	}

	if selectStatement.GetHavingClause() != nil {
		return fmt.Errorf("HAVING not supported")
	}

	if selectStatement.GetIntoClause() != nil {
		return fmt.Errorf("INTO not supported")
	}

	if selectStatement.GetSortClause() != nil {
		return fmt.Errorf("ORDER BY not supported")
	}

	if selectStatement.GetLockingClause() != nil {
		return fmt.Errorf("LOCK not supported")
	}

	if selectStatement.GetWindowClause() != nil {
		return fmt.Errorf("WINDOW not supported")
	}

	if selectStatement.GetLimitCount() != nil {
		return fmt.Errorf("LIMIT not supported")
	}

	return nil
}

type valueOrRef struct {
	fieldName             string
	value                 string
	parameterIndex        int32
	isSubQueryPlaceholder bool
}

func collectSelectWhereClauses(clause *pg_query.Node, fields map[string]valueOrRef) error {
	// bool_expr:{boolop:AND_EXPR  args:{a_expr:{kind:AEXPR_OP  name:{string:{sval:"="}}  lexpr:{column_ref:{fields:{string:{sval:"resource_type"}}  location:182}}  rexpr:{a_const:{sval:{sval:"2"}  location:198}}  location:196}}  args:{a_expr:{kind:AEXPR_OP  name:{string:{sval:"="}}  lexpr:{column_ref:{fields:{string:{sval:"resource_id"}}  location:210}}  rexpr:{a_const:{sval:{sval:"hi"}  location:224}}  location:222}}  location:204}
	switch {
	case clause.GetBoolExpr() != nil:
		if clause.GetBoolExpr().Boolop != pg_query.BoolExprType_AND_EXPR {
			return fmt.Errorf("only AND supported")
		}

		for _, arg := range clause.GetBoolExpr().Args {
			var err error
			if err = collectSelectWhereClauses(arg, fields); err != nil {
				return err
			}
		}

		return nil

	case clause.GetAExpr() != nil:
		aExpr := clause.GetAExpr()
		if len(aExpr.Name) != 1 || aExpr.Name[0].GetString_().Sval != "=" {
			return fmt.Errorf("only = supported")
		}

		leftRef, err := exprToValueOrRef(aExpr.Lexpr)
		if err != nil {
			return fmt.Errorf("failed to parse left expression: %w", err)
		}

		rightRef, err := exprToValueOrRef(aExpr.Rexpr)
		if err != nil {
			return fmt.Errorf("failed to parse right expression: %w", err)
		}

		fieldName := ""
		if leftRef.fieldName != "" && rightRef.fieldName != "" {
			return fmt.Errorf("only one side of the expression can be a column")
		}

		fieldValue := rightRef
		if leftRef.fieldName != "" {
			fieldName = leftRef.fieldName
		} else if rightRef.fieldName != "" {
			fieldName = rightRef.fieldName
			fieldValue = leftRef
		}

		if fieldName == "" {
			return fmt.Errorf("missing column name")
		}

		if _, ok := fields[fieldName]; ok {
			return fmt.Errorf("field %s already set", fieldName)
		}

		fields[fieldName] = fieldValue
		return nil
	}

	return fmt.Errorf("operation not supported: %v", clause)
}

func exprToValueOrRef(expr *pg_query.Node) (valueOrRef, error) {
	if expr.GetAConst() != nil {
		return valueOrRef{value: expr.GetAConst().GetSval().Sval}, nil
	}

	if expr.GetParamRef() != nil {
		return valueOrRef{parameterIndex: expr.GetParamRef().Number}, nil
	}

	if expr.GetColumnRef() != nil {
		if len(expr.GetColumnRef().Fields) != 1 {
			return valueOrRef{}, fmt.Errorf("only one column ref is supported")
		}

		return valueOrRef{fieldName: expr.GetColumnRef().Fields[0].GetString_().Sval}, nil
	}

	// ((SELECT null::text)::text)
	if expr.GetTypeCast() != nil {
		// TODO: find a better way to do this.
		if expr.GetTypeCast().GetTypeName() == nil {
			return valueOrRef{}, fmt.Errorf("type cast without type name")
		}

		if len(expr.GetTypeCast().GetTypeName().GetNames()) != 1 {
			return valueOrRef{}, fmt.Errorf("only one type name is supported")
		}

		if expr.GetTypeCast().GetTypeName().GetNames()[0].GetString_() == nil {
			return valueOrRef{}, fmt.Errorf("type name without string")
		}

		if expr.GetTypeCast().GetTypeName().GetNames()[0].GetString_().Sval != "text" {
			return valueOrRef{}, fmt.Errorf("only text type cast is supported")
		}

		if expr.GetTypeCast().GetArg() == nil {
			return valueOrRef{}, fmt.Errorf("type cast without argument")
		}

		sublink := expr.GetTypeCast().GetArg().GetSubLink()
		if sublink == nil {
			return valueOrRef{}, fmt.Errorf("type cast without sublink")
		}

		if sublink.GetSubLinkType() != pg_query.SubLinkType_EXPR_SUBLINK {
			return valueOrRef{}, fmt.Errorf("only EXPR_SUBLINK is supported")
		}

		if sublink.GetSubselect() == nil {
			return valueOrRef{}, fmt.Errorf("sublink without subselect")
		}

		if sublink.GetSubselect().GetSelectStmt() == nil {
			return valueOrRef{}, fmt.Errorf("sublink without select statement")
		}

		targetList := sublink.GetSubselect().GetSelectStmt().GetTargetList()
		if len(targetList) != 1 {
			return valueOrRef{}, fmt.Errorf("sublink with more than one target list")
		}

		targetListTypeCast := targetList[0].GetResTarget().GetVal().GetTypeCast()
		if targetListTypeCast == nil {
			return valueOrRef{}, fmt.Errorf("sublink without type cast")
		}

		if targetListTypeCast.GetTypeName() == nil {
			return valueOrRef{}, fmt.Errorf("sublink without type name")
		}

		if len(targetListTypeCast.GetTypeName().GetNames()) != 1 {
			return valueOrRef{}, fmt.Errorf("sublink with more than one type name")
		}

		if targetListTypeCast.GetTypeName().GetNames()[0].GetString_() == nil {
			return valueOrRef{}, fmt.Errorf("sublink without string")
		}

		if targetListTypeCast.GetTypeName().GetNames()[0].GetString_().Sval != "text" {
			return valueOrRef{}, fmt.Errorf("only text type cast is supported")
		}

		if targetListTypeCast.GetArg() == nil {
			return valueOrRef{}, fmt.Errorf("sublink without argument")
		}

		if targetListTypeCast.GetArg().GetAConst() == nil {
			return valueOrRef{}, fmt.Errorf("sublink without constant")
		}

		if !targetListTypeCast.GetArg().GetAConst().Isnull {
			return valueOrRef{}, fmt.Errorf("sublink with non-null constant")
		}

		return valueOrRef{isSubQueryPlaceholder: true}, nil
	}

	return valueOrRef{}, fmt.Errorf("unsupported expression type")
}
