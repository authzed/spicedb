package pgserver

import (
	"context"

	"github.com/authzed/spicedb/pkg/cmd/server/pgserver/tables"
	wire "github.com/jeroenrinzema/psql-wire"
	pg_query "github.com/pganalyze/pg_query_go/v6"
)

func (p *PgBackend) handleInsertStmt(ctx context.Context, stmt *pg_query.InsertStmt, query string) (wire.PreparedStatements, error) {
	parsed, err := tables.ParseInsertStatement(ctx, stmt)
	if err != nil {
		return nil, err
	}

	handle := func(ctx context.Context, writer wire.DataWriter, parameters []wire.Parameter) error {
		return parsed.ExecuteInsert(ctx, p.ds, writer, parameters)
	}

	params := wire.ParseParameters(query)
	return wire.Prepared(wire.NewStatement(handle, wire.WithParameters(params))), nil
}
