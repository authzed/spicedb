package pgserver

import (
	"context"
	"fmt"

	"github.com/authzed/ctxkey"
	"github.com/authzed/spicedb/pkg/cmd/server/pgserver/common"
	"github.com/authzed/spicedb/pkg/tuple"
	wire "github.com/jeroenrinzema/psql-wire"
	pg_query "github.com/pganalyze/pg_query_go/v6"
)

type session struct {
	withinTransaction bool
	cursors           map[string]*cursor
	writeOperation    *tuple.UpdateOperation
}

func (s *session) addCursor(cursor *cursor) {
	s.cursors[cursor.name] = cursor
}

func (s *session) deleteCursor(name string) {
	delete(s.cursors, name)
}

func (m *session) lookupCursor(name string) (*cursor, error) {
	cursor, ok := m.cursors[name]
	if !ok {
		return nil, common.NewSemanticsError(fmt.Errorf("cursor %q not found", name))
	}
	return cursor, nil
}

var sessionKey = ctxkey.New[*session]()

func sessionMiddleware(ctx context.Context) (context.Context, error) {
	return sessionKey.WithValue(ctx, &session{
		cursors: make(map[string]*cursor),
	}), nil
}

func mustSession(ctx context.Context) *session {
	return sessionKey.MustValue(ctx)
}

func getCursor(ctx context.Context, name string) (*cursor, bool) {
	c, ok := mustSession(ctx).cursors[name]
	return c, ok
}

func (p *PgBackend) handleDeallocateStmt(_ context.Context, stmt *pg_query.DeallocateStmt, _ string) (wire.PreparedStatements, error) {
	handle := func(ctx context.Context, writer wire.DataWriter, parameters []wire.Parameter) error {
		session := mustSession(ctx)
		if stmt.GetIsall() {
			session.cursors = make(map[string]*cursor)
			return writer.Complete("deallocated all")
		}

		if _, ok := getCursor(ctx, stmt.GetName()); ok {
			delete(session.cursors, stmt.GetName())
		}

		return writer.Complete("deallocated cursor")
	}
	return wire.Prepared(wire.NewStatement(handle)), nil
}
